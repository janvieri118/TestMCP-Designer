# Aurora MCP — add to an existing project

Connect Claude or Cursor to the remote Aurora MCP server. No design-system clone required.

## What's in the bundle

```
aurora-mcp-bundle.zip
├── INSTALL.md
├── tools/
│   └── aurora-mcp/
│       ├── launch-remote.mjs   ← connects Claude to Aurora MCP
│       ├── cert-bundle.mjs     ← corp TLS cert bundle (first run)
│       └── spawn-utils.mjs     ← cross-platform spawn helpers
└── examples/
    ├── mcp.json.snippet
    └── cursor-mcp.json.snippet
```

## Install

1. Download the bundle from the Aurora reference site: /guides/aurora-mcp
2. Unzip anywhere and review the contents (see tree above).
3. Copy `tools/` into your **project root** (same folder as `package.json`).
4. Create or edit `.mcp.json` at the project root — merge `examples/mcp.json.snippet`. Keep your other `mcpServers` entries.
5. (Optional) Merge `examples/cursor-mcp.json.snippet` into `.cursor/mcp.json`.
6. Restart Claude and ask: **List all Aurora components**

After step 3, your app should look like:

```
your-app/
├── package.json
└── tools/
    └── aurora-mcp/
        ├── launch-remote.mjs   ← entry point (.mcp.json points here)
        ├── cert-bundle.mjs     ← corp TLS cert bundle (first run)
        └── spawn-utils.mjs     ← cross-platform spawn helpers
```

Do **not** nest an extra folder (e.g. avoid `your-app/aurora-mcp-existing-project/tools/...`). `tools/` must sit directly under your app root.

First run creates `~/.config/aurora-mcp/certs/` from your OS trust store (corp TLS).

## More help

Aurora reference site: /guides/aurora-mcp
